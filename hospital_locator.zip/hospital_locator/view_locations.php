<?php
session_start();

// Check if the user is logged in as admin
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: login.php");  // Redirect to login if not logged in
    exit;
}

// Include the database connection
require_once('db.php');

// Default sorting column and direction
$sort_by = isset($_GET['sort_by']) ? $_GET['sort_by'] : 'timestamp';
$sort_order = isset($_GET['sort_order']) ? $_GET['sort_order'] : 'DESC';

// Handle search query by name
$search_query = '';
if (isset($_GET['search'])) {
    $search_query = $_GET['search'];
}

// Query to get location data with sorting options
$query = "SELECT * FROM location_reports WHERE user_name LIKE ? ORDER BY $sort_by $sort_order";
$stmt = mysqli_prepare($link, $query);
$search_term = '%' . $search_query . '%';
mysqli_stmt_bind_param($stmt, 's', $search_term);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

// Handle user deletion
if (isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];
    $delete_query = "DELETE FROM location_reports WHERE id = ?";
    $stmt = mysqli_prepare($link, $delete_query);
    mysqli_stmt_bind_param($stmt, 'i', $delete_id);
    mysqli_stmt_execute($stmt);
    header("Location: view_locations.php"); // Redirect after deletion
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Information</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="style.css"> <!-- Link to your custom style.css -->
</head>
<body>

    <!-- Navigation Bar -->
    <nav class="navbar navbar-expand-lg navbar-custom"> <!-- Add your custom class here -->
        <a class="navbar-brand" href="#">
            <img src="logo.png" alt="MediPoint Logo" class="navbar-logo" /> MediPoint
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item active">
                    <a class="nav-link" href="view_locations.php">User Information</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="about_us.php">About Us</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="logout.php">Logout</a>
                </li>
            </ul>
        </div>
    </nav>

    <!-- Content Area -->
    <div class="container mt-5">
        <h2>User Information</h2>

        <!-- Search Form -->
        <form method="GET" action="view_locations.php" class="mb-3">
            <div class="form-row">
                <div class="col-md-6">
                    <input type="text" class="form-control" name="search" value="<?= htmlspecialchars($search_query) ?>" placeholder="Search by Name">
                </div>
                <div class="col-md-2">
                    <button type="submit" class="btn btn-primary">Search</button>
                </div>
            </div>
        </form>

        <!-- Sorting Dropdown -->
        <div class="mb-3">
            <label for="sortOptions" class="form-label">Sort By:</label>
            <select id="sortOptions" class="form-control" onchange="window.location.href = this.value;">
                <option value="view_locations.php?sort_by=user_name&sort_order=ASC" <?= $sort_by == 'user_name' && $sort_order == 'ASC' ? 'selected' : '' ?>>Name (A-Z)</option>
                <option value="view_locations.php?sort_by=user_name&sort_order=DESC" <?= $sort_by == 'user_name' && $sort_order == 'DESC' ? 'selected' : '' ?>>Name (Z-A)</option>
                <option value="view_locations.php?sort_by=timestamp&sort_order=ASC" <?= $sort_by == 'timestamp' && $sort_order == 'ASC' ? 'selected' : '' ?>>Date (Oldest to Newest)</option>
                <option value="view_locations.php?sort_by=timestamp&sort_order=DESC" <?= $sort_by == 'timestamp' && $sort_order == 'DESC' ? 'selected' : '' ?>>Date (Newest to Oldest)</option>
            </select>
        </div>

        <!-- Table for User Information -->
        <table class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>User Name</th>
                    <th>Latitude</th>
                    <th>Longitude</th>
                    <th>Timestamp</th>
                    <th>User Agent</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (mysqli_num_rows($result) > 0): ?>
                    <?php while ($row = mysqli_fetch_assoc($result)): ?>
                    <tr>
                        <td><?= $row['id'] ?></td>
                        <td><?= $row['user_name'] ?></td>
                        <td><?= $row['latitude'] ?></td>
                        <td><?= $row['longitude'] ?></td>
                        <td><?= $row['timestamp'] ?></td>
                        <td><?= $row['user_agent'] ?></td>
                        <td>
                            <!-- Delete button -->
                            <a href="view_locations.php?delete_id=<?= $row['id'] ?>" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this user?')">Delete</a>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="7" class="text-center">No records found</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>

</body>
</html>
