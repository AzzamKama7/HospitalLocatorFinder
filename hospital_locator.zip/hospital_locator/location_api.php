<?php
require_once('db.php');

// Check if required data is set
if (!isset($_POST['latitude']) || !isset($_POST['longitude']) || !isset($_POST['user_name']) || !isset($_POST['user_email'])) {
    die("Error: Incomplete HTTP request");
}

// Sanitize inputs
$latitude = filter_input(INPUT_POST, 'latitude', FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);
$longitude = filter_input(INPUT_POST, 'longitude', FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);
$user_name = filter_input(INPUT_POST, 'user_name', FILTER_SANITIZE_STRING);
$user_email = filter_input(INPUT_POST, 'user_email', FILTER_SANITIZE_EMAIL);
$timestamp = date('Y-m-d H:i:s'); // Current timestamp
$user_agent = $_SERVER['HTTP_USER_AGENT']; // User's device info

// Check if sanitization was successful
if (!$latitude || !$longitude || !$user_name || !$user_email) {
    die("Error: Invalid input values");
}

// Validate email format
if (!filter_var($user_email, FILTER_VALIDATE_EMAIL)) {
    die("Error: Invalid email format");
}

// Prepare and bind the SQL query to avoid SQL injection
$query = "INSERT INTO location_reports (latitude, longitude, user_name, user_email, timestamp, user_agent) 
          VALUES (?, ?, ?, ?, ?, ?)";

$stmt = mysqli_prepare($link, $query);
mysqli_stmt_bind_param($stmt, 'ddssss', $latitude, $longitude, $user_name, $user_email, $timestamp, $user_agent);

// Execute the query
if (mysqli_stmt_execute($stmt)) {
    echo "Location data stored successfully";
} else {
    echo "Error: " . mysqli_error($link);
}

// Close the statement and connection
mysqli_stmt_close($stmt);
mysqli_close($link);
?>
