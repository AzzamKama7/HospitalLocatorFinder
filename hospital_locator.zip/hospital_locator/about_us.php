<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us</title>

    <!-- Link to Bootstrap CSS for basic styling -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">

    <!-- Link to custom CSS file (create 'style.css' for custom styles) -->
    <link rel="stylesheet" href="style.css">
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-custom">
    <a class="navbar-brand" href="#">
        <img src="logo.png" alt="MediPoint Logo" class="logo-img" /> MediPoint
    </a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link" href="view_locations.php">User Information</a>
            </li>
            <li class="nav-item active">
                <a class="nav-link" href="about_us.php">About Us</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="logout.php">Logout</a>
            </li>
        </ul>
    </div>
</nav>

<!-- Content -->
<div class="container mt-5">
    <h1 class="text-center">Meet Our Team</h1>
    <div class="row mt-4">
        <div class="col-md-4">
            <div class="card">
                <img src="team_member1.jpg" class="card-img-top" alt="Team Member 1">
                <div class="card-body">
                    <h5 class="card-title">MUHAMMAD MUAZZAM BIN MUSTAFFA KAMAL</h5>
                    <p class="card-text">Project Manager</p>
                    <p class="card-text">2023627786</p>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card">
                <img src="team_member2.png" class="card-img-top" alt="Team Member 2">
                <div class="card-body">
                    <h5 class="card-title">MUHAMMAD NUR ILHAM BIN MUHAMAD NAZIR</h5>
                    <p class="card-text">Developer</p>
                    <p class="card-text">2023898898</p>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card">
                <img src="team_member3.jpg" class="card-img-top" alt="Team Member 3">
                <div class="card-body">
                    <h5 class="card-title">MUHAMMAD KHAFI BIN KAMARULZAMAN</h5>
                    <p class="card-text">Designer</p>
                    <p class="card-text">2022487668</p>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- JS files for Bootstrap functionality -->
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>

</body>
</html>
