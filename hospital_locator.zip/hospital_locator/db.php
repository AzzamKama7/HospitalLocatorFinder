<?php
$host = "localhost";
$username = "root";
$password = "";
$database = "location_data";

// Create a connection
$link = mysqli_connect($host, $username, $password, $database);

// Check connection
if (!$link) {
    die("Connection failed: " . mysqli_connect_error());
}
?>
