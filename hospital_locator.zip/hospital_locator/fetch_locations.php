<?php
require_once('db.php');

$query = "SELECT * FROM location_reports ORDER BY timestamp DESC";
$result = mysqli_query($link, $query);

$output = array();
foreach ($result as $row) {
    array_push($output, $row);
}

// Convert the array to JSON format
$json = json_encode($output);

// Set the content type to JSON and output the result
header("Content-Type: application/json");
echo $json;
?>
