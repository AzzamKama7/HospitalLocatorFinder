<?php
session_start();

// Pre-defined admin credentials (in real applications, use a database)
$admin_username = "admin";
$admin_password = "admin123";  // In real cases, store a hashed password

// Handle login
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Check if credentials match
    if ($username === $admin_username && $password === $admin_password) {
        // Set session to mark the user as logged in
        $_SESSION['admin_logged_in'] = true;
        header("Location: view_locations.php");  // Redirect to the user info page (main dashboard)
        exit;
    } else {
        $error = "Invalid username or password!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="style.css"> <!-- Link to custom CSS file -->
</head>
<body>

    <div class="container d-flex">
        <div class="login-box">
            <!-- Logo -->
            <div class="text-center mb-4 login-logo">
                <img src="logo.png" alt="MediPoint Logo"/>
            </div>

            <!-- Title -->
            <h2 class="text-center mb-4">Admin Login</h2>

            <!-- Show error message if login failed -->
            <?php if (isset($error)) { echo "<p class='text-danger text-center'>$error</p>"; } ?>

            <!-- Login Form -->
            <form method="POST">
                <div class="form-group">
                    <label for="username">Username:</label>
                    <input type="text" class="form-control" id="username" name="username" required>
                </div>
                <div class="form-group">
                    <label for="password">Password:</label>
                    <input type="password" class="form-control" id="password" name="password" required>
                </div>
                <button type="submit" class="btn btn-primary btn-block">Login</button>
            </form>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>

</body>
</html>
